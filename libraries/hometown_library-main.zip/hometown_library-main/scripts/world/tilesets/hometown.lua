return {
  version = "1.10",
  luaversion = "5.1",
  tiledversion = "1.10.2",
  name = "hometown",
  class = "",
  tilewidth = 40,
  tileheight = 40,
  spacing = 0,
  margin = 0,
  columns = 11,
  image = "../../../assets/sprites/tilesets/bg_towntiles.png",
  imagewidth = 440,
  imageheight = 1040,
  objectalignment = "unspecified",
  tilerendersize = "tile",
  fillmode = "stretch",
  tileoffset = {
    x = 0,
    y = 0
  },
  grid = {
    orientation = "orthogonal",
    width = 40,
    height = 40
  },
  properties = {},
  wangsets = {},
  tilecount = 286,
  tiles = {}
}
