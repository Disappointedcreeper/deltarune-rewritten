<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="school" tilewidth="40" tileheight="40" tilecount="108" columns="9">
 <image source="../../../assets/sprites/tilesets/bg_schooltiles.png" width="360" height="480"/>
</tileset>
