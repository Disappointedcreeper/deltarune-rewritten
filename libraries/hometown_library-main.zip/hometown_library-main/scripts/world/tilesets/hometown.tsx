<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="hometown" tilewidth="40" tileheight="40" tilecount="286" columns="11">
 <editorsettings>
  <export target="hometown.lua" format="lua"/>
 </editorsettings>
 <image source="../../../assets/sprites/tilesets/bg_towntiles.png" width="440" height="1040"/>
</tileset>
